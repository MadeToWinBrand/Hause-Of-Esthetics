
Hause of Esthetics — Website Bundle
-----------------------------------

Files included:
- index.html
- styles.css
- assets/ (place your logo as assets/logo.png here)
- README.txt (this file)

What I completed for you:
- Full, responsive HTML + CSS website template with a luxury tan & black aesthetic.
- Embedded Acuity scheduler iframe (placeholder OWNER_ID).
- Contact placeholders for email and phone.
- Clean, minimal layout optimized for bookings.

What you must do to make this fully functional (quick steps):
1. Create an Acuity Scheduling account at https://acuityscheduling.com and obtain your Owner ID.
   - After logging into Acuity, go to 'Scheduling Page Link' or 'Embed Scheduler' in Account Settings.
   - The direct scheduling link looks like: https://acuityscheduling.com/schedule.php?owner=12345678
   - Replace "YOUR_OWNER_ID" in index.html iframe src with your actual owner number (e.g. 12345678).

2. Replace contact info:
   - Open index.html and replace the email (mailto:) and phone (tel:) with your real contact details.
   - Or edit the lines:
     Email: your@email.com
     Phone: +1 (123) 456-7890

3. Upload a logo:
   - Put a PNG named "logo.png" into the assets/ folder. The header will show it automatically.
   - Recommended size: 300x100 px (transparent background).

4. Host the site:
   - Upload all files to any static host (Netlify, Vercel, GitHub Pages, or your webhost).
   - If you use a website builder (Wix, Squarespace), use the page copy and the Acuity link to connect scheduling to your site.

5. Optional customizations:
   - Change colors in styles.css (:root variables --tan and --black).
   - Add Google Analytics or Pixel by inserting script tags into <head>.
   - For SSL and professional domain, set up DNS with your registrar and hosting provider.

Support:
If you'd like, I can:
- Swap placeholders for your real Owner ID, email, phone and logo (you paste them here).
- Generate a ZIP file (already included) and upload it to a hosting provider for you (you'll need to provide hosting credentials).
- Add extra pages, SEO tags, or mobile tweaks.

Notes about Acuity:
- The site includes an iframe scheduler; Acuity requires that you have a working Acuity account for booking and payments.
- You can enable deposits/payments inside your Acuity account — those policies will apply automatically.

How to share your real details securely:
- Reply with: YOUR_OWNER_ID, email, phone number, and (optionally) upload your logo file.
- I will insert them directly into the site files and regenerate the ZIP for download.

Thank you — your site is ready to be personalized and published!
